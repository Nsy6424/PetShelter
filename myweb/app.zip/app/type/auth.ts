export interface UserAuth {
  id: number;
  UserName?: string;
  MatKhau?: string;
  Hoten?: string;
  phone?: string;
  email?: string;
  MaVaiTro?: number;
  vaitro?: {
    Ten?: string;
  };
}
