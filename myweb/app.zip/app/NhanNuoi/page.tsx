import React from "react";
import NhanNuoi from "./component/NhanNuoi";

const page = () => {
  return (
    <div>
      
      <NhanNuoi></NhanNuoi>
    </div>
  );
};

export default page;
