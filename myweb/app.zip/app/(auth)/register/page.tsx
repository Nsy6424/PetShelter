import React from "react";
import RegisterForm from "./component/RegisterForm";

const Register = () => {
  return (
    <div>
      <RegisterForm></RegisterForm>
    </div>
  );
};

export default Register;
