export const USER_NOT_EXIST = {
  error_code: "KMNEXTAPP-001 ",
  message: "User khong ton tai",
};
